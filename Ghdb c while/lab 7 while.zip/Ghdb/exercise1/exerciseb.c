#include<stdio.h>
int main(){
int num=1;
do{
printf("%d\n",num);
num=num+2;
}
while(num<100);
}
