#include<stdio.h>
int main(){
for(int num=1;num<100;num=num+2){
	printf("%d\n",num);
	}
}
