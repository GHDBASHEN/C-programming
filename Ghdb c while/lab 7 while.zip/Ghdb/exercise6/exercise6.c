#include<stdio.h>
int main(){
int x;
int y,z;
float res;
do{
printf("My Calculator\n");
printf("-----------------------------\n");
printf("1.\tAddition\n");
printf("2.\tSubstraction\n");
printf("3.\tMultiplication\n");
printf("4.\tDivision\n");
printf("5.\tExit\n");
printf("Enter your option:");
scanf("%d",&x);}
while(x==5);
printf("Enter Numbers:");
scanf("%d%d",&y,&z);

switch(x){
case 1:
	res=y+z;
	break;
case 2:
	res=y-z;
	break;
case 3:
	res=y*z;
	break;
case 4:
	res=y/z;
	break;
default:
	printf("Insert valid number!\n");
	break;
}
printf("\n\nThe result is:%.2f\n",res);
return 0;
}
	
