#include<stdio.h>
int main(){

for(int x=1;x<=4;x++){
	for (int i=1;i<=x;i++){
		printf("%d",i);
		}
		printf("\n");
		}
return 0;
}
