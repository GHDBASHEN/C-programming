#include<stdio.h>
int main(){
for(int i=1;i<=4;i++){
	for(int x=1;x<=5;x++){
		printf("*");
	}
	printf("\n");
}
return 0;
}
